import { MigrationInterface, QueryRunner } from "typeorm";

export class AddSocieteTable1729772098378 implements MigrationInterface {
    name = 'AddSocieteTable1729772098378'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE \`societe\` (\`id\` int NOT NULL AUTO_INCREMENT, \`entreprise\` varchar(255) NOT NULL, \`nis\` varchar(255) NOT NULL, \`naaDivision\` varchar(255) NOT NULL, \`naaGroup\` varchar(255) NOT NULL, \`groupe\` varchar(255) NOT NULL, \`adresse\` varchar(255) NOT NULL, \`wilaya\` varchar(255) NOT NULL, \`codePostal\` varchar(255) NOT NULL, \`telephone\` varchar(255) NOT NULL, \`fax\` varchar(255) NULL, \`email\` varchar(255) NOT NULL, \`siteWeb\` varchar(255) NULL, \`activitePrincipale\` varchar(255) NOT NULL, \`activiteSecondaire\` varchar(255) NULL, \`effectifTotal\` int NOT NULL, \`effectifPermanents\` int NOT NULL, \`nombreUnites\` int NOT NULL, PRIMARY KEY (\`id\`)) ENGINE=InnoDB`);
        await queryRunner.query(`ALTER TABLE \`application_user_role\` DROP FOREIGN KEY \`FK_34ae70c064f705cb43a485fca8e\``);
        await queryRunner.query(`ALTER TABLE \`application_user_role\` DROP FOREIGN KEY \`FK_ee8f20f500fb4f33c845a89e17d\``);
        await queryRunner.query(`ALTER TABLE \`application_user_role\` CHANGE \`userId\` \`userId\` varchar(36) NULL`);
        await queryRunner.query(`ALTER TABLE \`application_user_role\` CHANGE \`applicationRoleId\` \`applicationRoleId\` varchar(36) NULL`);
        await queryRunner.query(`ALTER TABLE \`acsholding\` CHANGE \`societeMere\` \`societeMere\` varchar(100) NULL`);
        await queryRunner.query(`ALTER TABLE \`acsholding\` CHANGE \`logo\` \`logo\` varchar(255) NULL`);
        await queryRunner.query(`ALTER TABLE \`application_user\` DROP FOREIGN KEY \`FK_285f0096b86dd639a08068ce0d8\``);
        await queryRunner.query(`ALTER TABLE \`application_user\` CHANGE \`fullName\` \`fullName\` varchar(255) NULL`);
        await queryRunner.query(`ALTER TABLE \`application_user\` CHANGE \`isShowPhoneNumberInOdoo\` \`isShowPhoneNumberInOdoo\` tinyint NULL`);
        await queryRunner.query(`ALTER TABLE \`application_user\` CHANGE \`ACSHoldingId\` \`ACSHoldingId\` varchar(255) NULL`);
        await queryRunner.query(`ALTER TABLE \`application_user_role\` ADD CONSTRAINT \`FK_34ae70c064f705cb43a485fca8e\` FOREIGN KEY (\`userId\`) REFERENCES \`application_user\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE \`application_user_role\` ADD CONSTRAINT \`FK_ee8f20f500fb4f33c845a89e17d\` FOREIGN KEY (\`applicationRoleId\`) REFERENCES \`application_role\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE \`application_user\` ADD CONSTRAINT \`FK_285f0096b86dd639a08068ce0d8\` FOREIGN KEY (\`ACSHoldingId\`) REFERENCES \`acsholding\`(\`id\`) ON DELETE RESTRICT ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`application_user\` DROP FOREIGN KEY \`FK_285f0096b86dd639a08068ce0d8\``);
        await queryRunner.query(`ALTER TABLE \`application_user_role\` DROP FOREIGN KEY \`FK_ee8f20f500fb4f33c845a89e17d\``);
        await queryRunner.query(`ALTER TABLE \`application_user_role\` DROP FOREIGN KEY \`FK_34ae70c064f705cb43a485fca8e\``);
        await queryRunner.query(`ALTER TABLE \`application_user\` CHANGE \`ACSHoldingId\` \`ACSHoldingId\` varchar(255) NULL DEFAULT 'NULL'`);
        await queryRunner.query(`ALTER TABLE \`application_user\` CHANGE \`isShowPhoneNumberInOdoo\` \`isShowPhoneNumberInOdoo\` tinyint NULL DEFAULT 'NULL'`);
        await queryRunner.query(`ALTER TABLE \`application_user\` CHANGE \`fullName\` \`fullName\` varchar(255) NULL DEFAULT 'NULL'`);
        await queryRunner.query(`ALTER TABLE \`application_user\` ADD CONSTRAINT \`FK_285f0096b86dd639a08068ce0d8\` FOREIGN KEY (\`ACSHoldingId\`) REFERENCES \`acsholding\`(\`id\`) ON DELETE RESTRICT ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE \`acsholding\` CHANGE \`logo\` \`logo\` varchar(255) NULL DEFAULT 'NULL'`);
        await queryRunner.query(`ALTER TABLE \`acsholding\` CHANGE \`societeMere\` \`societeMere\` varchar(100) NULL DEFAULT 'NULL'`);
        await queryRunner.query(`ALTER TABLE \`application_user_role\` CHANGE \`applicationRoleId\` \`applicationRoleId\` varchar(36) NULL DEFAULT 'NULL'`);
        await queryRunner.query(`ALTER TABLE \`application_user_role\` CHANGE \`userId\` \`userId\` varchar(36) NULL DEFAULT 'NULL'`);
        await queryRunner.query(`ALTER TABLE \`application_user_role\` ADD CONSTRAINT \`FK_ee8f20f500fb4f33c845a89e17d\` FOREIGN KEY (\`applicationRoleId\`) REFERENCES \`application_role\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE \`application_user_role\` ADD CONSTRAINT \`FK_34ae70c064f705cb43a485fca8e\` FOREIGN KEY (\`userId\`) REFERENCES \`application_user\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`DROP TABLE \`societe\``);
    }

}
