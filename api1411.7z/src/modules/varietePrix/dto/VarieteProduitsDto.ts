export class VarieteProduitsDto {
    readonly id: string;
    readonly acsHoldingId: string;
    readonly variete: string;
    readonly observation :string;
    readonly unite: string;
    readonly codeNPA: number;
}