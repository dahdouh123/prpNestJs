export class DenominationProduitsDto {
    readonly id: string;
    readonly acsHoldingId: string;
    readonly denomination: string;
    readonly unite: string;
    readonly capaciteProd: number;
    readonly stockInitial:number;
}