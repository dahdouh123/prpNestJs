export enum Roles
{
    SuperAdminACS = 1,
    ManagerACS = 2,
    PcoFiliale = 3,
    AgentDeSaisieFiliale = 4,
    ManagerGroupe = 5,
    ManagerEpe = 6,

}