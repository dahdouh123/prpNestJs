// create-user.dto.ts
export class CreateUserDto {
    fullName: string;
    email: string;
    password: string;
    userName: string;
  }
  