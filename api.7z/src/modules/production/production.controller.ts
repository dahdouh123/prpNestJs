import { Body, Controller, Delete, Get, Param, Patch, Post, Put, Query } from '@nestjs/common';
import { ProductionService } from './production.service';
import { Production } from './entities/production.entity';
import { InsertProductionDto } from './dto/create-production.dto';
import { UpdateProductionDto } from './dto/update-production.dto';
import { ValiderDonneesProductionCommand } from './dto/valider-donnees-production.command';

@Controller('api/production')
export class ProductionController {
  constructor(private readonly productionService: ProductionService) {}

  @Post()
  async createProduction(@Body() createProductionDto: InsertProductionDto): Promise<Production> {
        return this.productionService.createProduction(createProductionDto);
  }


// Get all productions
@Get()
async getAll(): Promise<Production[]> {
  return this.productionService.findAll();
}
@Get('getProd')
async getProd(
  @Query('page') page: number,
  @Query('pageSize') pageSize: number,
  @Query('idUtilisateur') idUtilisateur: string
): Promise<{ data: Production[]; total: number }> {
  return this.productionService.getProductions(
    page,
    pageSize,
    idUtilisateur,
  );
}


// Update a production
@Patch(':id')
  async updateProduction(@Param('id') id: number, @Body() updateProductionDto: UpdateProductionDto): Promise<Production> {
    return this.productionService.updateProduction(id, updateProductionDto);
  }

// Delete a production
@Delete('supprimer/:id')
async remove(@Param('id') id: number): Promise<void> {
  return this.productionService.remove(id);
}

@Post('valider')
public async validateProduction(@Body() command: ValiderDonneesProductionCommand): Promise<void> {
    await this.productionService.validateProductionData(command);
}

}
