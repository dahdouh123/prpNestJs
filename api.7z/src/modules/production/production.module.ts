import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductionController } from './production.controller';
import { Production } from './entities/production.entity';
import { LignesProduction } from './entities/lignes-production.entity';
import { ProductionService } from './production.service';
import { Repository } from 'typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([Production,LignesProduction],'prpacs')],
  providers: [ProductionService ,Repository ],
  controllers: [ProductionController],
})
export class ProductionModule {}
