export class ValiderDonneesProductionCommand {
    constructor(public readonly id: number) {}
}