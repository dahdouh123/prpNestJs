// src/modules/tasks/tasks.controller.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { ProductionController } from './production.controller';
import { ProductionService } from './production.service';
import * as request from 'supertest';
import { INestApplication } from '@nestjs/common';
import { Production } from './entities/production.entity';

describe('ProductionController', () => {
  
});
