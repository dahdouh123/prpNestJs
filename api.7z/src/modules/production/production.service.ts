import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Production } from './entities/production.entity';
import { LignesProduction } from './entities/lignes-production.entity';
import { InsertProductionDto } from './dto/create-production.dto';
import { UpdateProductionDto } from './dto/update-production.dto';
import { ValiderDonneesProductionCommand } from './dto/valider-donnees-production.command';
import { validate } from 'class-validator';
import { ValidationException } from 'common/exceptions/validation.exception';

@Injectable()
export class ProductionService {
  constructor(
    @InjectRepository(Production, 'prpacs') // Specify database1
    private productionRepository: Repository<Production>,
    
    @InjectRepository(LignesProduction, 'prpacs') // Specify database1
    private lignesProductionRepository: Repository<LignesProduction>,
  ) {}

  async createProduction(createProductionDto: InsertProductionDto): Promise<Production> {
    const { affectationEPE, affectationFiliale, idUtilisateur, affectationGroupe, exercice, trimestre, lignesProduction  } = createProductionDto;
    
    // Check if the entire exercise (all trimesters) is already entered
    const existingTrimestres = await this.productionRepository
      .createQueryBuilder('production')
      .where('production.exercice = :exercice', { exercice })
      .andWhere('production.affectationEPE = :affectationEPE', { affectationEPE })
      .andWhere('production.affectationFiliale = :affectationFiliale', { affectationFiliale })
      .select('production.trimestre')
      .getMany();

    // If all 4 trimestres are entered, throw an error
    if (existingTrimestres.length === 4) {
      throw new BadRequestException('L\'exercice est déjà saisi.');
    }

    // Check if the specific trimestre is already entered
    const existingTrimestre = existingTrimestres.find(trimestreDoc => trimestreDoc.trimestre === trimestre);
    if (existingTrimestre) {
      throw new BadRequestException(`Le trimestre ${trimestre} de l'exercice ${exercice} est déjà saisi.`);
    }

    // Create a new Production entity
    const production = this.productionRepository.create({
      affectationEPE,
      idUtilisateur,
      affectationFiliale,
      affectationGroupe,
      exercice,
      trimestre,
      estValide: false,
    });
        // Save the production entity
    await this.productionRepository.save(production);

    // Create LignesProduction entities and link them to Production
    const lignesProductions = lignesProduction.map((ligne) => {
      return this.lignesProductionRepository.create({
        uniteMesureKilo:ligne.uniteMesureKilo,
        prodTrimestreValMDA:ligne.prodTrimestreValMDA,
        denomVariete: ligne.denomVariete,
        stockTrimestrePrec: ligne.stockTrimestrePrec,
        prodTrimestreQteC2: ligne.prodTrimestreQteC2,
        venteTrimestreQteD3: ligne.venteTrimestreQteD3,
        stockFinTrimestreReelQteF: ligne.stockFinTrimestreReelQteF,
        stockFinTrimestreTheo: ligne.stockFinTrimestreTheo,
        ecartStockReelTheo: ligne.ecartStockReelTheo,
        commentEcart: ligne.commentEcart,
        capProdQteG: ligne.capProdQteG,
        rappelQteProductionTrimestrePrecQteh: ligne.rappelQteProductionTrimestrePrecQteh,
        obs: ligne.obs,
        production,  // Associate the line with the production
      });
    });

    // Save all LignesProduction entities
    await this.lignesProductionRepository.save(lignesProductions);

    return production;
  }
   // Get all productions
   async findAll(): Promise<Production[]> {
    return this.productionRepository.find();
  }


  async updateProduction(id: number, updateProductionDto: UpdateProductionDto): Promise<Production> {
    const production = await this.productionRepository.findOne({
      where: { idDoc: id },
      relations: ['lignesProduction'],
    });

    if (!production) {
      throw new NotFoundException(`Production with ID ${id} not found`);
    }

    // Update production fields
    Object.assign(production, updateProductionDto);

    // Handle lines production
    const updatedLignesProduction = await Promise.all(
      updateProductionDto.lignesProduction.map(async (ligneDto) => {
        try {
          if (ligneDto.idLigne) {
            // Update existing line
            const ligne = await this.lignesProductionRepository.findOne({
              where: { idLigne: ligneDto.idLigne }});
                          if (!ligne) {
              console.warn(`Ligne with ID ${ligneDto.idLigne} not found for update`);
              return undefined; // Return undefined if not found
            }
            Object.assign(ligne, ligneDto); // Update properties
            return await this.lignesProductionRepository.save(ligne); // Save updated line
          } else {
            // Create new line
            const newLigne = this.lignesProductionRepository.create(ligneDto);
            return await this.lignesProductionRepository.save(newLigne);
          }
        } catch (error) {
          console.error('Error processing line:', ligneDto, error);
          return undefined; // Return undefined on error
        }
      }),
    );

    // Filter out any undefined results
    production.lignesProduction = updatedLignesProduction.filter(ligne => ligne !== undefined);

    // Save production
    return this.productionRepository.save(production);
  }
  // Delete a production
  async remove(id: number): Promise<void> {
    
    // Find the production with its related LignesProduction
    const production = await this.productionRepository.findOne({
      where: { idDoc: id }, // Assuming request has `id`
      relations: ['lignesProduction'],
    });

    if (!production) {
      throw new NotFoundException(`Production with ID ${id} not found`);
    }

    // Remove the production and its related entities
    await this.productionRepository.remove(production);
  
  }


  public async validateProductionData(request: ValiderDonneesProductionCommand): Promise<void> {
    const errors = await validate(request);
    if (errors.length > 0) {
        throw new ValidationException(errors);
    }

    const production = await this.productionRepository.findOne({ where: { idDoc: request.id } });

    if (production) {
        production.estValide = true;
        await this.productionRepository.save(production);
    } else {
        throw new NotFoundException(`Production with ID ${request.id} not found`);
    }
}


  async getProductions(
    page: number,
    pageSize: number,
    idUtilisateur: string,
  ): Promise<{ data: Production[]; total: number }> {
    const [productions, total] = await this.productionRepository.findAndCount({
       where: { idUtilisateur: idUtilisateur },
      relations: ['lignesProduction'],
      skip: (page - 1) * pageSize,
      take: pageSize,
    });

    return { data: productions, total };
  }
}
