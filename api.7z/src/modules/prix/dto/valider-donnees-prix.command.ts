export class ValiderDonneesPrixCommand {
    constructor(public readonly id: string) {}
}