import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ProductionService } from './production.service';
import { Production } from './entities/production.entity';

describe('ProductionService', () => {
 
  // Add more tests here for the service methods...
});
