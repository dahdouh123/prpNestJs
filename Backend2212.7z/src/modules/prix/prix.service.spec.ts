import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ProductionService } from './prix.service';
import { Production } from './entities/prix.entity';

describe('ProductionService', () => {
 
  // Add more tests here for the service methods...
});
